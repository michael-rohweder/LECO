﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Device.Location;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LECO
{

    static class Globals
    {
        public static List<CityData> cityData;
    }
    
    public class CityData
    {
        public string Name { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public double DistanceFromCurrentStop { get; set; }

        public CityData()
        { }
        public CityData(string Name, double Latitude, double Longitude)
        {
            this.Name = Name;
            this.Latitude = Latitude;
            this.Longitude = Longitude;
        }

        public override string ToString()
        {
            return Name;
        }
    }

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            selectedRoute.Text = "No Route Selected";
            LoadData();
        }

        public void LoadData()
        { 
            var listData = new List<CityData>();
            Globals.cityData = new List<CityData>();
            string[] lines = System.IO.File.ReadAllLines("./cities.csv");
            if (lines.Length > 0)
            {
                for (int i = 1; i < lines.Length; i++)
                {
                    string[] dataWords = lines[i].Split(',');
                    CityData city = new CityData(dataWords[0], Double.Parse(dataWords[1]), Double.Parse(dataWords[2]));
                    if (city.Name != "Albany (home base)")
                    {
                        listData.Add(city);
                    }
                    Globals.cityData.Add(city);

                }

                selectedCities.ItemsSource = listData;
            }

        }

        public double CalculateMiles(CityData city1, CityData city2)
        {
            var startCity = new GeoCoordinate(city1.Latitude, city1.Longitude);
            var endCity = new GeoCoordinate(city2.Latitude, city2.Longitude);

            return startCity.GetDistanceTo(endCity) * 0.0006213712;
        }

        private void SelectedCitiesListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {


            if (selectedCities.SelectedItem != null)
            {
                var selectedCityList = selectedCities.SelectedItems;
                List<CityData> cityList = new List<CityData>();
                foreach (CityData city in selectedCityList)
                {
                    cityList.Add(city);
                }

                int totalMiles = 0;
                int legMiles;
                var HOMEBASE = Globals.cityData[0];
                var currentCity = HOMEBASE;
                var nextCity = new CityData();
                selectedRoute.Text = "";

                while (cityList.Count > 0)
                {
                    double shortestDistance = 9999999999999;
                    for (int i = 0; i < cityList.Count; i++)
                    {
                        if (CalculateMiles(currentCity, (CityData)cityList[i]) < shortestDistance)
                        {
                            shortestDistance = CalculateMiles(currentCity, (CityData)cityList[i]);
                            nextCity = (CityData)cityList[i];
                        }
                    }
                    selectedRoute.Text += String.Format("From: {0}\nTo: {1}\n\tLeg Miles: {2}\n\n", currentCity, nextCity, (int)shortestDistance);
                    totalMiles += (int)shortestDistance;
                    cityList.Remove(nextCity);
                    currentCity = nextCity;
                } 

                legMiles = (int) CalculateMiles(currentCity, HOMEBASE);
                totalMiles += legMiles;
                selectedRoute.Text += String.Format("From: {0}\nTo: {1}\n\tLeg Miles:{2}\n\n", currentCity, HOMEBASE, legMiles);
                totalMilesTextBox.Text = totalMiles.ToString();
            } else
            {
                selectedRoute.Text = "No Route Selected";
                totalMilesTextBox.Text = "";
            }
        }
    }
}